package estacionamento.Pagamento;
public interface EstadoEstacionamento {
    public void vazio();
    public void lotado();
}
