package estacionamento.Pagamento;
public interface AcaoCancela {
    public void comportamento();
}
