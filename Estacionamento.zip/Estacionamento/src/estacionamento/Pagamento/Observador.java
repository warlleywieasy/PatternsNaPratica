package estacionamento.Pagamento;
public interface Observador {
    public void notificar();
}
